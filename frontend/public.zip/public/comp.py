from PIL import Image
import numpy as np

# Load original and WebP image
orig = np.array(Image.open("about.jpg"))
webp = np.array(Image.open("converted.webp"))

# Check if pixels are exactly equal
pixels_unchanged = np.array_equal(orig, webp)
print("Pixels unchanged:", pixels_unchanged)
